sap.ui.define([],
    function() {
        'use strict';
    
        var constants = {
            INTZERO: 0,
            httpPost: "POST",
            httpGet: "GET",
        };
        return constants;
    });
/*&--------------------------------------------------------------------------------------*
 * File name                    	   : editCust.controller.js	                     *
 * Created By                          : NThapa@marathonpetroleum.com                   *            	
 * Created On                          : 17-Oct-2022                                	 *                           							                                         *
 * Purpose                             : Controller for editCust.view.xml to edit Customer/ShipTo  
 *                                                                                                    
 *---------------------------------------------------------------------------------------*
 */
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/BusyIndicator",
    "sap/m/Token",
    "marathonpetroleum/hsc/pricingui/utils/constants",
    "sap/m/SearchField"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageBox, JSONModel, Filter, FilterOperator, BusyIndicator, Token, constants, SearchField) {
        "use strict";
        return Controller.extend("marathonpetroleum.hsc.pricingui.controller.editCust", {
            /**
              * Method to initialize all models and global variables
              * @public
              */
            onInit: function () {
                //fetch i18n model for text translation
                this.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                //fetch the service model
                this.oDataModelE = this.getOwnerComponent().getModel();
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("RouteEditView").attachPatternMatched(this.onRouteEditCustomer, this);
            },
            /**
      * Method for  Routing
      * @public
      */
            onRouteEditCustomer: function () {
                BusyIndicator.show();
                var oModel = new JSONModel(),that=this;
                var fgModel = this.getOwnerComponent().getModel("oModel");
                var aArray = fgModel.oData.selectedRow;
                
                this.oDataModelE.callFunction("/getCustomer", {
                    method: constants.httpGet,
                    async:false,
                    urlParameters: {
                        customer: aArray[constants.INTZERO].Customer,
                        shipTo: aArray[constants.INTZERO].ShipTo
                    },
                    success: function (oData) {
                        BusyIndicator.hide();
                        var oDataCust = oData.getCustomer.data;
                        if (oDataCust) {
                            
                            var etag = oData.getCustomer.data.UpdTimestamp,
                             eFormat = etag.match(/\(([^)]+)\)/)[1],
                             eDate = new Date(parseInt(eFormat)),
                             atomFormat = eDate.toISOString(),
                             aFormat = atomFormat.replace(/\.\d+Z$/, '');
                             that.getView().getModel("detailModel").setProperty("/CustEtag", aFormat);
                        }
                    },
                    error: function (err) {

                        BusyIndicator.hide();
                        MessageBox.error(that.oBundle.getText("techError"), {
                            details: err
                        });
                    }
                })
                this.getView().byId("idInputCustomerID").setValue(aArray[constants.INTZERO].Customer);
                this.getView().byId("idInputCustomerName").setValue(aArray[constants.INTZERO].CustomerName);
                this.getView().byId("idInputShipToID").setValue(aArray[constants.INTZERO].ShipTo);
                this.getView().byId("idInputShipToName").setValue(aArray[constants.INTZERO].ShipToName);
                this.getView().byId("idMultiComboBoxTerminal").removeAllTokens();
                this.getView().byId("idMultiComboBoxProducts").removeAllTokens();

                var tokenArray = [], tokenArrayT = [];
                if (aArray[constants.INTZERO].ProductList.length != constants.INTZERO) {
                    for (var i = constants.INTZERO; i < aArray[constants.INTZERO].ProductList.length; i++) {
                        var otokenProduct = new sap.m.Token({ key: aArray[constants.INTZERO].ProductList[i].Product, text: aArray[constants.INTZERO].ProductList[i].ProductName });
                        tokenArray.push(otokenProduct);
                    }
                    this.getView().byId("idMultiComboBoxProducts").setTokens(tokenArray);
                }
                if (aArray[constants.INTZERO].TerminalList.length != constants.INTZERO) {
                    for (var i = constants.INTZERO; i < aArray[constants.INTZERO].TerminalList.length; i++) {
                        var otokenTerminal = new sap.m.Token({ key: aArray[constants.INTZERO].TerminalList[i].Terminal, text: aArray[constants.INTZERO].TerminalList[i].TerminalName });
                        tokenArrayT.push(otokenTerminal);
                    }
                    this.getView().byId("idMultiComboBoxTerminal").setTokens(tokenArrayT);
                }
                oModel.setData({ "items": aArray[constants.INTZERO].EmailArray });
                //set model 
                this.getView().setModel(oModel, "detailModel");
                this.getView().byId("idInputEmail").setModel(oModel, "detailModel");
                this.getView().byId("idCheckBoxDaily").setSelected(aArray[constants.INTZERO].DailyJob);
                this.getView().byId("idCheckBoxOnDemand").setSelected(aArray[constants.INTZERO].OnDemandJob);
                this.getView().getModel("detailModel").setProperty("/ProductData", fgModel.oData.ProductData);
                this.getView().getModel("detailModel").setProperty("/TerminalData", fgModel.oData.TerminalData);
                

            },
            /**
      * Method to handle Save of create Customer 
      * @public 
      */
            onPressSaveEditCust: function () {
                var oCustID = this.getView().byId("idInputCustomerID").getValue(),
                    oCustName = this.getView().byId("idInputCustomerName").getValue(),
                    oSh = this.getView().byId("idInputShipToID").getValue(),
                    oSHName = this.getView().byId("idInputShipToName").getValue(),
                    oProd = this.getView().byId("idMultiComboBoxProducts").getTokens(),
                    oTermi = this.getView().byId("idMultiComboBoxTerminal").getTokens(),
                    oEmail = this.getView().byId("idInputEmail").getTokens(), that = this,
                    oDaily = this.getView().byId("idCheckBoxDaily").getSelected(), oProdArray = [], oTermiArray = [],
                    oDemand = this.getView().byId("idCheckBoxOnDemand").getSelected(), oEmailString = "";
                if (oDaily === true || oDemand === true) {
                    if (oProd.length === constants.INTZERO || oTermi.length === constants.INTZERO) {
                        BusyIndicator.hide();
                        MessageBox.error(that.oBundle.getText("errormsgCheckBox"));
                        return;
                    }
                }
                if (oCustID !== "" && oCustName !== "" && oSh !== "" && oSHName !== "" && oEmail.length !== constants.INTZERO) {
                    BusyIndicator.show();
                    for (var i = constants.INTZERO; i < oProd.length; i++) {
                        var objProd = {
                            "Customer": oCustID,
                            "ShipTo": oSh,
                            "Product": oProd[i].getKey()

                        };
                        oProdArray.push(objProd);
                    }
                    for (var i = constants.INTZERO; i < oTermi.length; i++) {
                        var objProd = {
                            "Customer": oCustID,
                            "ShipTo": oSh,
                            "Terminal": oTermi[i].getKey()
                        };
                        oTermiArray.push(objProd);
                    }
                    for (var j = constants.INTZERO; j < oEmail.length; j++) {
                        var objEmail = oEmail[j].getKey();
                        if (j === constants.INTZERO) {
                            oEmailString = objEmail;
                        } else {
                            oEmailString = oEmailString + constants.spliter + objEmail;
                        }

                    }
                    var oJsonData = {
                        "Customer": oCustID,
                        "ShipTo": oSh,
                        "CustomerName": oCustName,
                        "ShipToName": oSHName,
                        "DailyJob": oDaily,
                        "OnDemandJob": oDemand,
                        "EmailTo": oEmailString,
                        "ProductList": oProdArray,
                        "TerminalList": oTermiArray
                    }
                    var that = this;
                    var oPayloadCus = JSON.stringify(oJsonData),
                        etag = this.getView().getModel("detailModel").getProperty("/CustEtag");

                    that.oDataModelE.callFunction("/updateCustomer", {
                        method: constants.httpPost,
                        urlParameters: {
                            etag: etag,
                            createData: oPayloadCus
                        },
                        success: function (oData) {
                            BusyIndicator.hide();
                            if (oData.updateCustomer.data.status !== undefined && oData.updateCustomer.data.status !== 200) {
                                if (oData.updateCustomer.data.status === 412) {
                                    var msg = that.oBundle.getText("msgError");
                                    MessageBox.error(msg);
                                } else {
                                    var msg = oData.updateCustomer.data.message;
                                    MessageBox.error(msg);
                                }
                                
                            }
                            else {
                                that.getView().getModel("detailModel").setProperty("/CustEtag", constants.SPACE)
                                MessageBox.success(that.oBundle.getText("savedSucc"), {
                                    onClose: function (sAction) {
                                        if (sAction === MessageBox.Action.OK) {
                                            that.onBack();
                                            BusyIndicator.hide();

                                        }
                                    }
                                });
                            }
                        },
                        error: function (err) {
                            BusyIndicator.hide();
                            var msg = err.message; 
                            MessageBox.error(msg, {
                                details: err
                            });

                        }
                    });


                } else {
                    BusyIndicator.hide();
                    MessageBox.error(that.oBundle.getText("errormsgrequired"));
                }
            },
            /**
      * Method to navigate Back through navigation
      * @public
      */
            onBack: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RoutecontrolView");
            },
            /**
      * Method to validation on Email MutiInput
      * @public
      * @param {sap.ui.base.Event} oEvt An Event object consisting of an ID, a source and a map of parameter
      */
            onEmailChangeEditCust: function (oEvt) {
                var oMultiInput1 = this.getView().byId("idInputEmail");
                var sVal = oEvt.getParameters().value;
                var fnValidator = function (args) {
                    var email = args.text;
                    // var eArr = email.split('@');
                    var mailregex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
                    if (!mailregex.test(email)) {
                        oMultiInput1.setValueState(sap.ui.core.ValueState.Error);
                    } else {
                        oMultiInput1.setValueState(sap.ui.core.ValueState.None);
                        return new Token({ key: email, text: email });
                    }
                };
                if (sVal === "") {
                    oMultiInput1.setValueState(sap.ui.core.ValueState.None);
                }
                oMultiInput1.addValidator(fnValidator);
            },

            /**
       * Method to handle the fragment TerminalVH
       * @public
       */
            onTerminalValueHelpRequested: function () {
                this._oBasicSearchField = new SearchField();
                this.oColModel = new JSONModel();
                var aCols = {
                    "cols": [
                        {
                            "label": "Terminal ID",
                            "template": "Terminal",
                        },
                        {
                            "label": "Terminal Name",
                            "template": "TerminalName"
                        }
                    ]
                };
                this.oTerminalModel = this.getView().getModel("detailModel");
                this.oColModel.setData(aCols);
                this._oValueHelpDialogTr = sap.ui.xmlfragment(constants.fragmentTerVH, this);
                this.getView().addDependent(this._oValueHelpDialogTr);
                // Set Basic Search for FilterBar
                var oFilterBar = this._oValueHelpDialogTr.getFilterBar();
                oFilterBar.setFilterBarExpanded(false);
                oFilterBar.setBasicSearch(this._oBasicSearchField);

                // Trigger filter bar search when the basic search is fired
                this._oBasicSearchField.attachSearch(function () {
                    oFilterBar.search();
                });
                this._oValueHelpDialogTr.getTableAsync().then(function (oTable) {
                    oTable.setModel(this.oTerminalModel);
                    oTable.setModel(this.oColModel, "columns");

                    if (oTable.bindRows) {
                        oTable.bindAggregation("rows", "/TerminalData");
                    }

                    if (oTable.bindItems) {
                        oTable.bindAggregation("items", "/TerminalData", function () {
                            return new ColumnListItem({
                                cells: aCols.map(function (column) {
                                    return new Label({ text: "{" + column.template + "}" });
                                })
                            });
                        });
                    }
                    this._oValueHelpDialogTr.update();
                }.bind(this));

                this._oValueHelpDialogTr.setTokens(this.getView().byId("idMultiComboBoxTerminal").getTokens());
                this._oValueHelpDialogTr.open();
            },
            /**
       * Method to handle search on Terminal F4 
       * @public
       * @param {sap.ui.base.Event} oEvent An Event object consisting of an ID, a source and a map of parameter
       */
            onFilterBarSearchTer: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");
                var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        if (oControl.getName() === "Terminal ID") {
                            aResult.push(new Filter({
                                path: constants.pathTer,
                                operator: FilterOperator.Contains,
                                value1: oControl.getValue()
                            }));
                        } else if (oControl.getName() === constants.terName) {
                            aResult.push(new Filter({
                                path: constants.pathTName,
                                operator: FilterOperator.Contains,
                                value1: oControl.getValue()
                            }));
                        }
                    }
                    return aResult;
                }, []);
                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: constants.pathTer, operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: constants.pathTName, operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));
                this._filterTableTr(new Filter({
                    filters: aFilters,
                    and: true
                }));
            },
            _filterTableTr: function (oFilter) {
                var oVHD = this._oValueHelpDialogTr;
                oVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }
                    // This method must be called after binding update of the table.
                    oVHD.update();
                });
            },
            /**
  * Method to handle confirm on TerminalVH
  * @public
  * @param {sap.ui.base.Event} oEvent An Event object consisting of an ID, a source and a map of parameter
  */
            onValueHelpOkPressTer: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                this.getView().byId("idMultiComboBoxTerminal").setTokens(aTokens);
                this._oValueHelpDialogTr.close();
            },
            onValueHelpCancelPressTer: function () {
                this._oValueHelpDialogTr.close();
                this._oValueHelpDialogTr.destroy();
            },
            /**
      * Method to handle the fragment ProductVH
      * @public
      */
            onProductsValueHelpRequested: function () {
                this._oBasicSearchField = new SearchField();
                this.oColModel = new JSONModel();
                var aCols = {
                    "cols": [
                        {
                            "label": "Product ID",
                            "template": "Product",
                        },
                        {
                            "label": "Product Name",
                            "template": "ProductName"
                        }
                    ]
                };

                this.oProductsModel = this.getView().getModel("detailModel");

                this.oColModel.setData(aCols);
                this._oValueHelpDialog = sap.ui.xmlfragment(constants.fragmentProdVH, this);
                this.getView().addDependent(this._oValueHelpDialog);
                // Set Basic Search for FilterBar
                var oFilterBar = this._oValueHelpDialog.getFilterBar();
                oFilterBar.setFilterBarExpanded(false);
                oFilterBar.setBasicSearch(this._oBasicSearchField);

                // Trigger filter bar search when the basic search is fired
                this._oBasicSearchField.attachSearch(function () {
                    oFilterBar.search();
                });
                this._oValueHelpDialog.getTableAsync().then(function (oTable) {
                    oTable.setModel(this.oProductsModel);
                    oTable.setModel(this.oColModel, "columns");

                    if (oTable.bindRows) {
                        oTable.bindAggregation("rows", "/ProductData");
                    }

                    if (oTable.bindItems) {
                        oTable.bindAggregation("items", "/ProductData", function () {
                            return new ColumnListItem({
                                cells: aCols.map(function (column) {
                                    return new Label({ text: "{" + column.template + "}" });
                                })
                            });
                        });
                    }
                    this._oValueHelpDialog.update();
                }.bind(this));

                this._oValueHelpDialog.setTokens(this.getView().byId("idMultiComboBoxProducts").getTokens());
                this._oValueHelpDialog.open();
            },
            /**
      * Method to handle search on Product F4 
      * @public
      * @param {sap.ui.base.Event} oEvent An Event object consisting of an ID, a source and a map of parameter
      */
            onFilterBarSearchProd: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");
                var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        if (oControl.getName() === "Product ID") {
                            aResult.push(new Filter({
                                path: constants.pathProd,
                                operator: FilterOperator.Contains,
                                value1: oControl.getValue()
                            }));
                        } else if (oControl.getName() === constants.prodName) {
                            aResult.push(new Filter({
                                path: constants.pathProdName,
                                operator: FilterOperator.Contains,
                                value1: oControl.getValue()
                            }));
                        }
                    }
                    return aResult;
                }, []);
                aFilters.push(new Filter({
                    filters: [
                        new Filter({ path: constants.pathProd, operator: FilterOperator.Contains, value1: sSearchQuery }),
                        new Filter({ path: constants.pathProdName, operator: FilterOperator.Contains, value1: sSearchQuery })
                    ],
                    and: false
                }));
                this._filterTable(new Filter({
                    filters: aFilters,
                    and: true
                }));
            },
            _filterTable: function (oFilter) {
                var oVHD = this._oValueHelpDialog;
                oVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }
                    // This method must be called after binding update of the table.
                    oVHD.update();
                });
            },
            /**
       * Method to handle confirm on ProductVH
       * @public
       * @param {sap.ui.base.Event} oEvent An Event object consisting of an ID, a source and a map of parameter
       */
            onValueHelpOkPressProd: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                this.getView().byId("idMultiComboBoxProducts").setTokens(aTokens);
                this._oValueHelpDialog.close();
            },
            /**
       * Method to handle cancel on ProductVH
       * @public
       * @param {sap.ui.base.Event} oEvent An Event object consisting of an ID, a source and a map of parameter
       */
            onValueHelpCancelPressProd: function () {
                this._oValueHelpDialog.close();
                this._oValueHelpDialog.destroy();
            },
            /**
       * Method to handle afterclose on ProductVH
       * @public
       * @param {sap.ui.base.Event} oEvent An Event object consisting of an ID, a source and a map of parameter
       */
            onValueHelpAfterClose: function () {
                this._oValueHelpDialog.destroy();
            },
                                    /**
             * retrieve data from JSON model
            * async-Promise-style for Qunit
            *
            * @return {Promise}
            */
                                    getTodosViaPromise: function () {
                                        return new Promise(function (fnResolve, fnReject) {
                                            var oModel = this.getView().getModel();
                                            if (!oModel) {
                                                fnReject("couldn't load the application model")
                                            } else {
                                                fnResolve(oModel.getProperty("/todos"));
                                            }
                                        }.bind(this))
                                    }
        });
    });
